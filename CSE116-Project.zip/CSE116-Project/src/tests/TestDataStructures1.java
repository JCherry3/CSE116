package tests;

import org.junit.Test;
import static org.junit.Assert.*;
import ratings.Rating;
import ratings.Reviewer;
import ratings.Song;
import ratings.datastructures.LinkedListNode;
import static tests.TestClasses1.compareRatings;

public class TestDataStructures1 {
    public static boolean compareListsOfRatings(LinkedListNode<Rating> list1,LinkedListNode<Rating> list2){
        if(list1 == null ^ list2 == null){
            return false;
        }
        if(list1 == null && list2 == null){
            return true;
        }
        boolean comp;
        LinkedListNode<Rating> tmpl1 = new LinkedListNode<>(list1.getValue(),list1.getNext());
        LinkedListNode<Rating> tmpl2 = new LinkedListNode<>(list2.getValue(),list2.getNext());
        int size1 = 0;
        int size2 = 0;
        while(tmpl1.getNext() != null){
            size1++;
            tmpl1 = tmpl1.getNext();
        }
        while(tmpl2.getNext() != null){
            size2++;
            tmpl2 = tmpl2.getNext();
        }
        if(size1 != size2){
            return false;
        }
        while(list1.getNext() != null){
            comp = compareRatings(list1.getValue(),list2.getValue());
            if(!comp){
                return false;
            }
            else{
                list1 = list1.getNext();
                list2 = list2.getNext();
            }
        }
        comp = compareRatings(list1.getValue(),list2.getValue());
        return comp;
    }
    //Test Data
    Song song1 = new Song("I KNOW?","Travis Scott","Utopia10");
    Song song2 = new Song("Reminder","The Weeknd","Starboy4");
    Song song3 = new Song("Champion","Kanye West","Graduation2");
    Song song4 = new Song("Burn","¥$","VULTURES19");
    Song song11 = new Song("I KNOW?","Travis Scott","Utopia10");
    Song song21 = new Song("Reminder","The Weeknd","Starboy4");
    Song song31 = new Song("Champion","Kanye West","Graduation2");
    Rating rating1 = new Rating("MusicLover123",4);
    Rating rating2 = new Rating("SongText123",1);
    Rating rating3 = new Rating("PopOnline42",2);
    Rating rating4 = new Rating("NightMusic88",1);
    Rating rating5 = new Rating("RockGuitar777",5);
    Rating rating6 = new Rating("AudioNews808",4);
    Rating rating7 = new Rating("FreshTunes2023",3);
    Rating rating8 = new Rating("NerdsInHoodies13",5);
    Rating rating9 = new Rating("GrooveMaster808",2);
    Rating rating10 = new Rating("LyricLover13",3);
    Rating rating11 = new Rating("BeatMusic42",5);
    Rating rating12 = new Rating("RhythmRebel99",4);
    Rating rating91 = new Rating("GrooveMaster808",20);
    Rating rating101 = new Rating("LyricLover13",-5);
    Rating rating111 = new Rating("BeatMusic42",5);
    Rating rating121 = new Rating("RhythmRebel99",4);
    Reviewer rev1 = new Reviewer("PopOnline42");
    Reviewer rev2 = new Reviewer("NerdsInHoodies13");
    Reviewer rev3 = new Reviewer("GrooveMaster808");
    @Test
    public void testAverageRating(){
        song1.addRating(rating1);
        song1.addRating(rating2);
        song1.addRating(rating3);
        song1.addRating(rating4);
        song2.addRating(rating5);
        song2.addRating(rating6);
        song2.addRating(rating7);
        song2.addRating(rating8);
        song3.addRating(rating91);
        song3.addRating(rating101);
        song3.addRating(rating111);
        song3.addRating(rating121);
        assertEquals("error in averageRating() test 1",2,song1.averageRating(),0.01);
        assertEquals("error in averageRating() test 2",4.25,song2.averageRating(),0.01);
        assertEquals("error in averageRating() test 3",4.5,song3.averageRating(),0.01);
        assertEquals("error in averageRating() test 4",0.0,song4.averageRating(),0.01);
    }
    @Test
    public void testRemoveRatingByReviewer(){
        song1.addRating(rating1);
        song1.addRating(rating2);
        song1.addRating(rating3);
        song1.addRating(rating4);
        song11.addRating(rating1);
        song11.addRating(rating2);
        song11.addRating(rating4);
        song1.removeRatingByReviewer(rev1);
        song2.addRating(rating5);
        song2.addRating(rating6);
        song2.addRating(rating7);
        song2.addRating(rating8);
        song21.addRating(rating5);
        song21.addRating(rating6);
        song21.addRating(rating7);
        song2.removeRatingByReviewer(rev2);
        song3.addRating(rating9);
        song3.addRating(rating10);
        song3.addRating(rating11);
        song3.addRating(rating12);
        song31.addRating(rating10);
        song31.addRating(rating11);
        song31.addRating(rating12);
        song3.removeRatingByReviewer(rev3);
        assertTrue("error in removeRatingByReview() test 1",compareListsOfRatings(song1.getRatings(),song11.getRatings()));
        assertTrue("error in removeRatingByReview() test 2",compareListsOfRatings(song2.getRatings(),song21.getRatings()));
        assertTrue("error in removeRatingByReview() test 3",compareListsOfRatings(song3.getRatings(),song31.getRatings()));
    }
}
