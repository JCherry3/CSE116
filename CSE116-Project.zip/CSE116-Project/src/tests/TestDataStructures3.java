package tests;

import org.junit.Test;
import static org.junit.Assert.*;
import static ratings.FileReader.*;
import ratings.DegreesOfSeparation;
public class TestDataStructures3 {
    DegreesOfSeparation bacon = new DegreesOfSeparation(readMovies("data/movies.csv"));
    @Test
    public void testDegreesOfSeparation(){
        assertEquals("Error in test 1",2,bacon.degreesOfSeparation("Tim Allen","John Spencer"));
        assertEquals("Error in test 2",0,bacon.degreesOfSeparation("Tom Hanks","Tom Hanks"));
        assertEquals("Error in test 3",3,bacon.degreesOfSeparation("Gotz Otto","Mariah Carey"));
        assertEquals("Error in test 4",4,bacon.degreesOfSeparation("Bette Midler","Kanji Tsuda"));
        assertEquals("Error in test 5",-1,bacon.degreesOfSeparation("Tim Allen","Portia de Rossi"));
    }
}
