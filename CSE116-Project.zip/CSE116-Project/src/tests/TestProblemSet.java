package tests;

import org.junit.Test;
import ratings.ProblemSet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import static java.util.Arrays.asList;
import static javax.management.Query.or;
import static org.junit.Assert.*;

public class TestProblemSet {
    @Test
    public void testAverage(){
        ArrayList<Double> avg1 = new ArrayList<>(Arrays.asList(1.0,2.0,3.0));
        ArrayList<Double> avg2 = new ArrayList<>(Arrays.asList(-5.0,5.0));
        ArrayList<Double> avg3 = new ArrayList<>(Arrays.asList(6.5,6.5,8.5,8.5));
        ArrayList<Double> avg4 = new ArrayList<>();
        ArrayList<Double> avg5 = new ArrayList<>(Arrays.asList(10.0));
        ArrayList<ArrayList<Double>> avIn = new ArrayList<>(Arrays.asList(avg1,avg2,avg3,avg4,avg5));
        ArrayList<Double> avAns = new ArrayList<>(Arrays.asList(2.0,0.0,7.5,0.0,10.0));
        for(int i=0;i<avIn.size();i++){
            String x = Integer.toString(i);
            double in = ProblemSet.average(avIn.get(i));
            double ans = avAns.get(i);
            assertEquals("error in average() test " + x,ans,in,0.01);
        }
    }

    @Test
    public void testSumOfDigits(){
        ArrayList<Integer> sdAns = new ArrayList<>(Arrays.asList(11,18,0,6,12,9,12,4));
        ArrayList<Integer> sdIn = new ArrayList<>(Arrays.asList(542,-387,0,123,57,-36,90210,-1111));
        for(int i=0;i<sdIn.size();i++){
            int x = sdAns.get(i);
            int y = ProblemSet.sumOfDigits(sdIn.get(i));
            String z = Integer.toString(i);
            assertEquals("error in sumOfDigits() test " + z,x,y);
        }
    }

    @Test
    public void testBestKey(){
        HashMap<String,Integer> dict1 = new HashMap<>();
        dict1.put("CSE",100);
        dict1.put("MTH",90);
        dict1.put("MGT",10);
        HashMap<String,Integer> dict2 = new HashMap<>();
        dict2.put("cat",5);
        dict2.put("dog",5);
        dict2.put("fox",4);
        ArrayList<String> expOut = new ArrayList<>(Arrays.asList("dog","cat"));
        HashMap<String,Integer> dict3 = new HashMap<>();
        HashMap<String,Integer> dict4 = new HashMap<>();
        dict4.put("CSE",-100);
        dict4.put("MTH",-90);
        dict4.put("MGT",-10);
        assertSame("error in bestKey() test 1","CSE", ProblemSet.bestKey(dict1));
        assertTrue("error in bestKey() test 2",expOut.contains(ProblemSet.bestKey(dict2)));
        assertSame("error in bestKey() test 3","", ProblemSet.bestKey(dict3));
        assertSame("error in bestKey() test 4","MGT", ProblemSet.bestKey(dict4));
    }
    // TODO: Write testing for all 3 methods of the ratings.ProblemSet class
    public static void main(String[] args){
    }
}
