package tests;

import org.junit.Test;

import static org.junit.Assert.*;

import ratings.Rating;
import ratings.Reviewer;
import ratings.Song;

public class TestClasses1 {
    public static boolean compareSongs(Song s1,Song s2){
        boolean b1 = (s1.getTitle().equals(s2.getTitle()));
        boolean b2 = (s1.getArtist().equals(s2.getArtist()));
        boolean b3 = (s1.getSongID().equals(s2.getSongID()));
        boolean b4 = false;
        if(b1){
            if(b2){
                if(b3){
                    b4 = true;
                }
            }
        }
        return b4;
    }
    public static boolean compareRatings(Rating r1, Rating r2){
        boolean b5 = (r1.getReviewerID().equals(r2.getReviewerID()));
        boolean b6 = (r1.getRating() == r2.getRating());
        boolean b7 = false;
        if(b5){
            if(b6){
                b7 = true;
            }
        }
        return b7;
    }
    public static boolean compareReviewers(Reviewer v1, Reviewer v2){
        return (v1.getReviewerID().equals(v2.getReviewerID()));
    }
    Song testSong1 = new Song("Reminder","The Weeknd","Starboy4");
    Song testSong2 = new Song("I KNOW?","Travis Scott","Utopia10");
    Song testSong3 = new Song("Champion","Kanye West","Graduation2");

    Rating testRating1 = new Rating("ChantArchitect42",2);
    Rating testRating2 = new Rating("TechNinja007",4);
    Rating testRating3 = new Rating("CodeMaster99",1);
    Rating testRating4 = new Rating("GamerGal42",5);
    Rating testRating5 = new Rating("MusicLover123",3);
    Rating testRating6 = new Rating("Bookworm1984",2);
    Rating testRating7 = new Rating("FreshBeats2023",-5);
    Reviewer testReviewer1 = new Reviewer("GamerGal42");
    Reviewer testReviewer2 = new Reviewer("MusicLover123");
    Reviewer testReviewer3 = new Reviewer("Bookworm1984");
    Reviewer testReviewer4 = new Reviewer("FreshBeats2023");
    Reviewer testReviewer5 = new Reviewer(":P");
    @Test
    public void testRateSong(){
        assertTrue("Error in RateSong() test 1",compareRatings(testReviewer1.rateSong(5),testRating4));
        assertTrue("Error in RateSong() test 2",compareRatings(testReviewer2.rateSong(3),testRating5));
        assertTrue("Error in RateSong() test 3",compareRatings(testReviewer3.rateSong(2),testRating6));
        assertTrue("Error in RateSong() test 4",compareRatings(testReviewer4.rateSong(10),testRating7));
    }
    @Test
    public void testSetTitle(){
        Song testSong11 = new Song("unknown","The Weeknd","Starboy4");
        Song testSong21 = new Song("unknown","Travis Scott","Utopia10");
        Song testSong31 = new Song("unknown","Kanye West","Graduation2");
        testSong11.setTitle("Reminder");
        assertTrue("Error in setTitle() test 1",compareSongs(testSong11,testSong1));
        testSong21.setTitle("I KNOW?");
        assertTrue("Error in setTitle() test 2",compareSongs(testSong21,testSong2));
        testSong31.setTitle("Champion");
        assertTrue("Error in setTitle() test 3",compareSongs(testSong31,testSong3));
    }
    @Test
    public void testSetArtist(){
        Song testSong12 = new Song("Reminder","unknown","Starboy4");
        Song testSong22 = new Song("I KNOW?","unknown","Utopia10");
        Song testSong32 = new Song("Champion","unknown","Graduation2");
        testSong12.setArtist("The Weeknd");
        assertTrue("Error in setArtist() test 1",compareSongs(testSong12,testSong1));
        testSong22.setArtist("Travis Scott");
        assertTrue("Error in setArtist() test 2",compareSongs(testSong22,testSong2));
        testSong32.setArtist("Kanye West");
        assertTrue("Error in setArtist() test 3",compareSongs(testSong32,testSong3));
    }
    @Test
    public void testSetSongID(){
        Song testSong13 = new Song("Reminder","The Weeknd","unknown");
        Song testSong23 = new Song("I KNOW?","Travis Scott","unknown");
        Song testSong33 = new Song("Champion","Kanye West","unknown");
        testSong13.setSongID("Starboy4");
        assertTrue("Error in setSongID() test 1",compareSongs(testSong13,testSong1));
        testSong23.setSongID("Utopia10");
        assertTrue("Error in setSongID() test 2",compareSongs(testSong23,testSong2));
        testSong33.setSongID("Graduation2");
        assertTrue("Error in setSongID() test 3",compareSongs(testSong33,testSong3));
    }
    @Test
    public void testRatingSetReviewerID(){
        Rating testRating11 = new Rating("unknown",2);
        Rating testRating21 = new Rating("unknown",4);
        Rating testRating31 = new Rating("unknown",1);
        Rating testRating41 = new Rating("unknown",5);
        Rating testRating51 = new Rating("unknown",3);
        testRating11.setReviewerID("ChantArchitect42");
        assertTrue("Error in Rating.setReviewerID() test 1",compareRatings(testRating11,testRating1));
        testRating21.setReviewerID("TechNinja007");
        assertTrue("Error in Rating.setReviewerID() test 2",compareRatings(testRating21,testRating2));
        testRating31.setReviewerID("CodeMaster99");
        assertTrue("Error in Rating.setReviewerID() test 3",compareRatings(testRating31,testRating3));
        testRating41.setReviewerID("GamerGal42");
        assertTrue("Error in Rating.setReviewerID() test 3",compareRatings(testRating41,testRating4));
        testRating51.setReviewerID("MusicLover123");
        assertTrue("Error in Rating.setReviewerID() test 3",compareRatings(testRating51,testRating5));
    }
    @Test
    public void testSetRating(){
        Rating testRating12 = new Rating("ChantArchitect42",-1);
        Rating testRating22 = new Rating("TechNinja007",-1);
        Rating testRating32 = new Rating("CodeMaster99",-1);
        Rating testRating72 = new Rating("FreshBeats2023",3);
        testRating12.setRating(2);
        assertTrue("Error in setRating() test 1",compareRatings(testRating12,testRating1));
        testRating22.setRating(4);
        assertTrue("Error in setRating() test 2",compareRatings(testRating22,testRating2));
        testRating32.setRating(1);
        assertTrue("Error in setRating() test 3",compareRatings(testRating32,testRating3));
        testRating72.setRating(8);
        assertTrue("Error in setRating() test 4",compareRatings(testRating72,testRating7));
    }
    @Test
    public void testReviewerSetReviewerID(){
        Reviewer testReviewer11 = new Reviewer("");
        Reviewer testReviewer21 = new Reviewer("");
        Reviewer testReviewer31 = new Reviewer("");
        Reviewer testReviewer41 = new Reviewer("");
        Reviewer testReviewer51 = new Reviewer("");
        testReviewer11.setReviewerID("GamerGal42");
        assertTrue("Error in Reviewer.setReviewerID() test 1",compareReviewers(testReviewer11,testReviewer1));
        testReviewer21.setReviewerID("MusicLover123");
        assertTrue("Error in Reviewer.setReviewerID() test 2",compareReviewers(testReviewer21,testReviewer2));
        testReviewer31.setReviewerID("Bookworm1984");
        assertTrue("Error in Reviewer.setReviewerID() test 3",compareReviewers(testReviewer31,testReviewer3));
        testReviewer41.setReviewerID("FreshBeats2023");
        assertTrue("Error in Reviewer.setReviewerID() test 3",compareReviewers(testReviewer41,testReviewer4));
        testReviewer51.setReviewerID(":P");
        assertTrue("Error in Reviewer.setReviewerID() test 3",compareReviewers(testReviewer51,testReviewer5));
    }
}