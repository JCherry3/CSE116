package tests;

import org.junit.Test;
import static org.junit.Assert.*;
import ratings.Movie;
import ratings.Rating;
import ratings.Song;
import static ratings.FileReader.*;
import static tests.TestDataStructures1.*;
import static tests.TestClasses2.*;
import java.util.ArrayList;
import java.util.Arrays;

public class TestFiles {
    public static boolean findMovie(Movie mov,ArrayList<Movie> movies){
        boolean check = false;
        for(Movie movie : movies){
            if(mov.getTitle().equals(movie.getTitle()) && compareArrayListsIgnoreCase(mov.getCast(),movie.getCast())){
                check = compareListsOfRatings(mov.getRatings(),movie.getRatings());
            }else{
                check = false;
            }
            if(check){
                break;
            }
        }
        return check;
    }
    public static boolean findSong(Song sng,ArrayList<Song> songs){
        boolean check = false;
        for(Song song : songs){
            if(sng.getTitle().equals(song.getTitle()) && sng.getArtist().equals(song.getArtist())){
                if(sng.getSongID().equals(song.getSongID())){
                    check = compareListsOfRatings(sng.getRatings(),song.getRatings());
                }else {
                    check = false;
                }
            }else{
                check = false;
            }
            if(check){
                break;
            }
        }
        return check;
    }
    public static boolean compareMovieArrayLists(ArrayList<Movie> movs1,ArrayList<Movie> movs2){
        if(movs1.isEmpty() && movs2.isEmpty()){
            return true;
        }
        if(movs1.size() == movs2.size()){
            for(Movie mov1 : movs1){
                if(!findMovie(mov1,movs2)){
                    return false;
                }
            }
        }else{
            return false;
        }
        return true;
    }
    public static boolean compareSongArrayLists(ArrayList<Song> sngs1, ArrayList<Song> sngs2){
        if(sngs1.isEmpty() && sngs2.isEmpty()){
            return true;
        }
        if(sngs1.size() == sngs2.size()){
            for(Song sng1 : sngs1){
                if(!findSong(sng1,sngs2)){
                    return false;
                }
            }
        }else{
            return false;
        }
        return true;
    }
    Song song0 = new Song("Nightcore", "Ken Carson", "6p1j9OP2IBdzR5tgtyJk10");
    Rating rat1 = new Rating("221", 5);
    Song song1 = new Song("Ric Flair Drip (with Metro Boomin)", "Offset", "7sO5G9EABYOXQKNPNiE9NR");
    Rating rat2 = new Rating("243", 5);
    Song song2 = new Song("Flashing Lights", "Kanye West", "5TRPicyLGbAF2LGBFbHGvO");
    Rating rat3 = new Rating("40", 5);
    Rating rat4 = new Rating("38", 2);
    Rating rat5 = new Rating("223", 3);
    Rating rat6 = new Rating("46", 5);
    Rating rat7 = new Rating("66", 4);
    Song song3 = new Song("Endless Fashion", "Lil Uzi Vert", "41bmnQZoDMQdDh5zyomtW7");
    Rating rat8 = new Rating("117", 5);
    Rating rat9 = new Rating("248", 5);
    Rating rat10 = new Rating("219", 3);
    Rating rat11 = new Rating("82", 3);
    Rating rat12 = new Rating("66", 3);
    Song song4 = new Song("Video Games", "Lana Del Rey", "24jvD83UgLmrdGjhWTFslY");
    Rating rat13 = new Rating("127", 5);
    Rating rat14 = new Rating("66", 3);
    Song song5 = new Song("Knockin' On Heaven's Door", "Bob Dylan", "6HSXNV0b4M4cLJ7ljgVVeh");
    Rating rat15 = new Rating("51", 5);
    Rating rat16 = new Rating("89", 3);
    Rating rat17 = new Rating("91", 4);
    Rating rat18 = new Rating("163", 2);
    Rating rat19 = new Rating("219", 1);
    Rating rat20 = new Rating("146", 5);
    Rating rat21 = new Rating("28", 1);
    Rating rat22 = new Rating("41", 4);
    Rating rat23 = new Rating("66", 4);
    Song song6 = new Song("Viva La Vida", "Coldplay", "1mea3bSkSGXuIRvnydlB5b");
    Rating rat24 = new Rating("232", 4);
    Rating rat25 = new Rating("91", 3);
    Rating rat26 = new Rating("249", 4);
    Rating rat27 = new Rating("171", 2);
    Rating rat28 = new Rating("181", 4);
    Rating rat29 = new Rating("165", 5);
    Rating rat30 = new Rating("244", 2);
    Rating rat31 = new Rating("219", 4);
    Rating rat32 = new Rating("213", 5);
    Rating rat33 = new Rating("164", 4);
    Rating rat34 = new Rating("209", 4);
    Rating rat35 = new Rating("158", 4);
    Rating rat36 = new Rating("259", 4);
    Rating rat37 = new Rating("185", 5);
    Rating rat38 = new Rating("41", 5);
    Rating rat39 = new Rating("215", 5);
    Rating rat40 = new Rating("66", 3);
    Song song7 = new Song("Barricades", "Hiroyuki Sawano", "6iaQi9uPzHoXLMo5g490Bj");
    Rating rat41 = new Rating("232", 4);
    Song song8 = new Song("Dragonball Durag", "Thundercat", "62PclpoBFLl50PJpiJA5RT");
    Rating rat42 = new Rating("116", 5);
    Rating rat43 = new Rating("82", 3);
    Rating rat44 = new Rating("140", 4);
    Rating rat45 = new Rating("223", 2);
    Song song9 = new Song("Sunflower", "Post Malone", "3KkXRkHbMCARz0aVfEt68P");
    Rating rat46 = new Rating("58", 5);
    Rating rat47 = new Rating("215", 3);
    Rating rat48 = new Rating("86", 4);
    Movie mov1 = new Movie("Toy Story",new ArrayList<String>(Arrays.asList("Tom Hanks","Tim Allen","Don Rickles","Wallace Shawn","John Ratzenberger","Annie Potts","John Morris","Laurie Metcalf","R. Lee Ermey","Penn Jillette")));
    Movie mov2 = new Movie("Jumanji",new ArrayList<String>(Arrays.asList("Robin Williams","Jonathan Hyde","Kirsten Dunst","Bonnie Hunt","Bebe Neuwirth","David Alan Grier","Patricia Clarkson","James Handy","Malcolm Stewart","Darryl Henriques")));
    Movie mov3 = new Movie("Father of the Bride Part II",new ArrayList<String>(Arrays.asList("Steve Martin","Diane Keaton","Martin Short","Kimberly Williams-Paisley","George Newbern","Kieran Culkin","BD Wong","Peter Michael Goetz","Kate McGregor-Stewart","Jane Adams","Eugene Levy","Lori Alan")));
    Movie mov4 = new Movie("Heat",new ArrayList<>(Arrays.asList("Al Pacino","Robert De Niro","Val Kilmer","Jon Voight","Tom Sizemore","Diane Venora","Amy Brenneman","Ashley Judd","Mykelti Williamson","Natalie Portman","Ted Levine","Tom Noonan","Hank Azaria","Wes Studi","Dennis Haysbert","Danny Trejo","Henry Rollins","William Fichtner","Kevin Gage","Susan Traylor","Jeremy Piven","Xander Berkeley","Begonya Plaza","Rick Avery","Steven Ford","Paul Herman","Brian Libby","Thomas Rosales Jr.","Yvonne Zima","Bud Cort","Martin Ferrero","Robert Miranda","Philip Ettington")));
    Movie mov5 = new Movie("GoldenEye",new ArrayList<>(Arrays.asList("Pierce Brosnan","Sean Bean","Izabella Scorupco","Famke Janssen","Joe Don Baker","Judi Dench","Gottfried John","Robbie Coltrane","Alan Cumming","Tcheky Karyo","Desmond Llewelyn","Samantha Bond","Michael Kitchen","Simon Kunz","Billy J. Mitchell","Constantine Gregory","Minnie Driver","Michelle Arthur","Ravil Isyanov")));
    Movie mov6 = new Movie("The American President",new ArrayList<>(Arrays.asList("Michael Douglas","Annette Bening","Michael J. Fox","Martin Sheen","Anna Deavere Smith","Samantha Mathis","David Paymer","Richard Dreyfuss","Nina Siemaszko","Wendie Malick","Beau Billingslea","Joshua Malina","Clement von Franckenstein","John Mahoney","Gabriel Jarret")));
    Movie mov7 = new Movie("Dracula: Dead and Loving It",new ArrayList<>(Arrays.asList("Leslie Nielsen","Mel Brooks","Amy Yasbeck","Peter MacNicol","Harvey Korman","Steven Weber","Megan Cavanagh","Gregg Binkley","Anne Bancroft")));
    Movie mov8 = new Movie("Balto",new ArrayList<>(Arrays.asList("Kevin Bacon","Bob Hoskins","Bridget Fonda","Jim Cummings","Jack Angel","Danny Mann","Robbie Rist","Frank Welker","Miriam Margolyes")));
    Movie mov9 = new Movie("Cutthroat Island",new ArrayList<>(Arrays.asList("Geena Davis","Matthew Modine","Frank Langella","Maury Chaykin","Patrick Malahide","Stan Shaw","Rex Linn","Paul Dillon","Christopher Masterson","Harris Yulin","Angus Wright","Richard Leaf","Rupert Vansittart","Nick Bartlett","David Bailie","Christopher Adamson")));
    Movie movRats1 = new Movie("Toy Story",new ArrayList<String>(Arrays.asList("Tom Hanks","Tim Allen","Don Rickles","Wallace Shawn","John Ratzenberger","Annie Potts","John Morris","Laurie Metcalf","R. Lee Ermey","Penn Jillette")));
    Movie movRats2 = new Movie("Jumanji",new ArrayList<String>(Arrays.asList("Robin Williams","Jonathan Hyde","Kirsten Dunst","Bonnie Hunt","Bebe Neuwirth","David Alan Grier","Patricia Clarkson","James Handy","Malcolm Stewart","Darryl Henriques")));
    Movie movRats3 = new Movie("Father of the Bride Part II",new ArrayList<String>(Arrays.asList("Steve Martin","Diane Keaton","Martin Short","Kimberly Williams-Paisley","George Newbern","Kieran Culkin","BD Wong","Peter Michael Goetz","Kate McGregor-Stewart","Jane Adams","Eugene Levy","Lori Alan")));
    Movie movRats4 = new Movie("Heat",new ArrayList<>(Arrays.asList("Al Pacino","Robert De Niro","Val Kilmer","Jon Voight","Tom Sizemore","Diane Venora","Amy Brenneman","Ashley Judd","Mykelti Williamson","Natalie Portman","Ted Levine","Tom Noonan","Hank Azaria","Wes Studi","Dennis Haysbert","Danny Trejo","Henry Rollins","William Fichtner","Kevin Gage","Susan Traylor","Jeremy Piven","Xander Berkeley","Begonya Plaza","Rick Avery","Steven Ford","Paul Herman","Brian Libby","Thomas Rosales Jr.","Yvonne Zima","Bud Cort","Martin Ferrero","Robert Miranda","Philip Ettington")));
    Movie movRats5 = new Movie("GoldenEye",new ArrayList<>(Arrays.asList("Pierce Brosnan","Sean Bean","Izabella Scorupco","Famke Janssen","Joe Don Baker","Judi Dench","Gottfried John","Robbie Coltrane","Alan Cumming","Tcheky Karyo","Desmond Llewelyn","Samantha Bond","Michael Kitchen","Simon Kunz","Billy J. Mitchell","Constantine Gregory","Minnie Driver","Michelle Arthur","Ravil Isyanov")));
    Movie movRats6 = new Movie("The American President",new ArrayList<>(Arrays.asList("Michael Douglas","Annette Bening","Michael J. Fox","Martin Sheen","Anna Deavere Smith","Samantha Mathis","David Paymer","Richard Dreyfuss","Nina Siemaszko","Wendie Malick","Beau Billingslea","Joshua Malina","Clement von Franckenstein","John Mahoney","Gabriel Jarret")));
    Movie movRats7 = new Movie("Dracula: Dead and Loving It",new ArrayList<>(Arrays.asList("Leslie Nielsen","Mel Brooks","Amy Yasbeck","Peter MacNicol","Harvey Korman","Steven Weber","Megan Cavanagh","Gregg Binkley","Anne Bancroft")));
    Movie movRats8 = new Movie("Balto",new ArrayList<>(Arrays.asList("Kevin Bacon","Bob Hoskins","Bridget Fonda","Jim Cummings","Jack Angel","Danny Mann","Robbie Rist","Frank Welker","Miriam Margolyes")));
    Movie movRats9 = new Movie("Cutthroat Island",new ArrayList<>(Arrays.asList("Geena Davis","Matthew Modine","Frank Langella","Maury Chaykin","Patrick Malahide","Stan Shaw","Rex Linn","Paul Dillon","Christopher Masterson","Harris Yulin","Angus Wright","Richard Leaf","Rupert Vansittart","Nick Bartlett","David Bailie","Christopher Adamson")));
    Rating movrat1 = new Rating("189",1);
    Rating movrat2 = new Rating("127",3);
    Rating movrat3 = new Rating("28",2);
    Rating movrat4 = new Rating("304",2);
    Rating movrat5 = new Rating("1",5);
    Rating movrat6 = new Rating("19",4);
    Rating movrat7 = new Rating("232",2);
    Rating movrat8 = new Rating("242",5);
    Rating movrat9 = new Rating("102",4);
    Rating movrat10 = new Rating("23",3);
    Rating movrat11 = new Rating("23",3);
    Rating movrat12 = new Rating("190",4);
    Rating movrat13 = new Rating("214",2);
    Rating movrat14 = new Rating("432",1);
    Rating movrat15 = new Rating("1",1);
    Rating movrat16 = new Rating("134",2);
    Rating movrat17 = new Rating("123",4);
    Rating movrat18 = new Rating("222",3);
    Rating movrat19 = new Rating("90",4);
    Rating movrat20 = new Rating("45",5);
    Rating movrat21 = new Rating("3",3);
    Rating movrat22 = new Rating("265",2);
    Rating movrat23 = new Rating("312",2);
    Rating movrat24 = new Rating("321",4);
    Rating movrat25 = new Rating("187",5);
    Rating movrat26 = new Rating("12",3);
    Rating movrat27 = new Rating("13",4);
    Rating movrat28 = new Rating("83",2);
    ArrayList<Movie> movies1 = new ArrayList<>(Arrays.asList(mov1,mov2,mov3));
    ArrayList<Movie> movies2 = new ArrayList<>(Arrays.asList(mov4,mov5,mov6));
    ArrayList<Movie> movies3 = new ArrayList<>(Arrays.asList(mov7,mov8,mov9));
    ArrayList<Movie> movies4 = new ArrayList<>();
    @Test
    public void testReadSongs(){
        song0.addRating(rat1);
        song1.addRating(rat2);
        song2.addRating(rat3);
        song2.addRating(rat4);
        song2.addRating(rat5);
        song2.addRating(rat6);
        song2.addRating(rat7);
        song3.addRating(rat8);
        song3.addRating(rat9);
        song3.addRating(rat10);
        song3.addRating(rat11);
        song3.addRating(rat12);
        song4.addRating(rat13);
        song4.addRating(rat14);
        song5.addRating(rat15);
        song5.addRating(rat16);
        song5.addRating(rat17);
        song5.addRating(rat18);
        song5.addRating(rat19);
        song5.addRating(rat20);
        song5.addRating(rat21);
        song5.addRating(rat22);
        song5.addRating(rat23);
        song6.addRating(rat24);
        song6.addRating(rat25);
        song6.addRating(rat26);
        song6.addRating(rat27);
        song6.addRating(rat28);
        song6.addRating(rat29);
        song6.addRating(rat30);
        song6.addRating(rat31);
        song6.addRating(rat32);
        song6.addRating(rat33);
        song6.addRating(rat34);
        song6.addRating(rat35);
        song6.addRating(rat36);
        song6.addRating(rat37);
        song6.addRating(rat38);
        song6.addRating(rat39);
        song6.addRating(rat40);
        song7.addRating(rat41);
        song8.addRating(rat42);
        song8.addRating(rat43);
        song8.addRating(rat44);
        song8.addRating(rat45);
        song9.addRating(rat46);
        song9.addRating(rat47);
        song9.addRating(rat48);
        ArrayList<Song> songs1 = new ArrayList<>(Arrays.asList(song0,song1,song2,song3));
        ArrayList<Song> songs2 = new ArrayList<>(Arrays.asList(song4,song5,song6));
        ArrayList<Song> songs3 = new ArrayList<>(Arrays.asList(song7,song8,song9));
        ArrayList<Song> songs4 = new ArrayList<>();
        assertTrue("error in readSongs() test 1",compareSongArrayLists(readSongs("data/songs1.csv"),songs1));
        assertTrue("error in readSongs() test 2",compareSongArrayLists(readSongs("data/songs2.csv"),songs2));
        assertTrue("error in readSongs() test 3",compareSongArrayLists(readSongs("data/songs3.csv"),songs3));
        assertTrue("error in readSongs() test 4",compareSongArrayLists(readSongs("data/songs11.csv"),songs4));
    }
    @Test
    public void testReadMovies(){
        assertTrue("error in readMovies() test 1",compareMovieArrayLists(readMovies("data/movies1.csv"),movies1));
        assertTrue("error in readMovies() test 2",compareMovieArrayLists(readMovies("data/movies2.csv"),movies2));
        assertTrue("error in readMovies() test 3",compareMovieArrayLists(readMovies("data/movies3.csv"),movies3));
        assertTrue("error in readMovies() test 4",compareMovieArrayLists(readMovies("data/mooovies.csv"),movies4));
    }
    @Test
    public void testReadMovieRatings(){
        movRats1.addRating(movrat1);
        movRats1.addRating(movrat2);
        movRats1.addRating(movrat3);
        movRats2.addRating(movrat4);
        movRats2.addRating(movrat5);
        movRats3.addRating(movrat6);
        movRats4.addRating(movrat7);
        movRats4.addRating(movrat8);
        movRats4.addRating(movrat9);
        movRats4.addRating(movrat10);
        movRats5.addRating(movrat11);
        movRats5.addRating(movrat12);
        movRats5.addRating(movrat13);
        movRats5.addRating(movrat14);
        movRats5.addRating(movrat15);
        movRats6.addRating(movrat16);
        movRats6.addRating(movrat17);
        movRats6.addRating(movrat18);
        movRats7.addRating(movrat19);
        movRats7.addRating(movrat20);
        movRats7.addRating(movrat21);
        movRats7.addRating(movrat22);
        movRats7.addRating(movrat23);
        movRats8.addRating(movrat24);
        movRats8.addRating(movrat25);
        movRats8.addRating(movrat26);
        movRats8.addRating(movrat27);
        movRats9.addRating(movrat28);
        ArrayList<Movie> movsRats1 = new ArrayList<>(Arrays.asList(movRats1,movRats2,movRats3));
        ArrayList<Movie> movsRats2 = new ArrayList<>(Arrays.asList(movRats4,movRats5,movRats6));
        ArrayList<Movie> movsRats3 = new ArrayList<>(Arrays.asList(movRats7,movRats8,movRats9));
        assertTrue("error in readMovieRatings() test 1",compareMovieArrayLists(readMovieRatings(movies1,"data/movieRatings2.csv"),movsRats1));
        assertTrue("error in readMovieRatings() test 2",compareMovieArrayLists(readMovieRatings(movies2,"data/movieRatings2.csv"),movsRats2));
        assertTrue("error in readMovieRatings() test 3",compareMovieArrayLists(readMovieRatings(movies3,"data/movieRatings2.csv"),movsRats3));
        assertTrue("error in readMovieRatings() test 4",compareMovieArrayLists(readMovieRatings(movies1,"data/mooovie_ratingssss.csv"),movies4));
    }
}
