package tests;

import org.junit.Test;
import static org.junit.Assert.*;
import ratings.MediaLibrary;
import ratings.Movie;
import ratings.Ratable;
import ratings.Song;
import java.util.ArrayList;
import java.util.Arrays;

public class TestClasses3 {
    public static boolean findRatable(Ratable media, ArrayList<Ratable> list) {
        for (Ratable item : list) {
            if (media.getTitle().equals(item.getTitle())) {
                return true;
            }
        }
        return false;
    }

    public static boolean compareRatableArrayLists(ArrayList<Ratable> list1, ArrayList<Ratable> list2) {
        if (list1.size() != list2.size()) {
            return false;
        }
        for (Ratable media : list1) {
            if (!findRatable(media, list2)) {
                return false;
            }
        }
        return true;
    }

    Song song1 = new Song("Ric Flair Drip (with Metro Boomin)", "Offset", "7sO5G9EABYOXQKNPNiE9NR");
    Song song2 = new Song("Endless Fashion", "Lil Uzi Vert", "41bmnQZoDMQdDh5zyomtW7");
    Song song3 = new Song("Flashing Lights", "Kanye West", "5TRPicyLGbAF2LGBFbHGvO");
    Movie mov1 = new Movie("Father of the Bride Part II", new ArrayList<String>(Arrays.asList("Steve Martin", "Diane Keaton", "Martin Short", "Kimberly Williams-Paisley", "George Newbern", "Kieran Culkin", "BD Wong", "Peter Michael Goetz", "Kate McGregor-Stewart", "Jane Adams", "Eugene Levy", "Lori Alan")));
    Song song4 = new Song("Nightcore", "Ken Carson", "6p1j9OP2IBdzR5tgtyJk10");
    Movie mov2 = new Movie("Jumanji", new ArrayList<String>(Arrays.asList("Robin Williams", "Jonathan Hyde", "Kirsten Dunst", "Bonnie Hunt", "Bebe Neuwirth", "David Alan Grier", "Patricia Clarkson", "James Handy", "Malcolm Stewart", "Darryl Henriques")));
    Movie mov3 = new Movie("Toy Story", new ArrayList<String>(Arrays.asList("Tom Hanks", "Tim Allen", "Don Rickles", "Wallace Shawn", "John Ratzenberger", "Annie Potts", "John Morris", "Laurie Metcalf", "R. Lee Ermey", "Penn Jillette")));
    ArrayList<Ratable> items1 = new ArrayList<>(Arrays.asList(song1, song2, song3, mov1, song4, mov2, mov3));
    Song song5 = new Song("Viva La Vida", "Coldplay", "1mea3bSkSGXuIRvnydlB5b");
    Song song6 = new Song("Video Games", "Lana Del Rey", "24jvD83UgLmrdGjhWTFslY");
    Movie mov4 = new Movie("Heat", new ArrayList<>(Arrays.asList("Al Pacino", "Robert De Niro", "Val Kilmer", "Jon Voight", "Tom Sizemore", "Diane Venora", "Amy Brenneman", "Ashley Judd", "Mykelti Williamson", "Natalie Portman", "Ted Levine", "Tom Noonan", "Hank Azaria", "Wes Studi", "Dennis Haysbert", "Danny Trejo", "Henry Rollins", "William Fichtner", "Kevin Gage", "Susan Traylor", "Jeremy Piven", "Xander Berkeley", "Begonya Plaza", "Rick Avery", "Steven Ford", "Paul Herman", "Brian Libby", "Thomas Rosales Jr.", "Yvonne Zima", "Bud Cort", "Martin Ferrero", "Robert Miranda", "Philip Ettington")));
    Song song7 = new Song("Knockin' On Heaven's Door", "Bob Dylan", "6HSXNV0b4M4cLJ7ljgVVeh");
    Movie mov5 = new Movie("The American President", new ArrayList<>(Arrays.asList("Michael Douglas", "Annette Bening", "Michael J. Fox", "Martin Sheen", "Anna Deavere Smith", "Samantha Mathis", "David Paymer", "Richard Dreyfuss", "Nina Siemaszko", "Wendie Malick", "Beau Billingslea", "Joshua Malina", "Clement von Franckenstein", "John Mahoney", "Gabriel Jarret")));
    Movie mov6 = new Movie("GoldenEye", new ArrayList<>(Arrays.asList("Pierce Brosnan", "Sean Bean", "Izabella Scorupco", "Famke Janssen", "Joe Don Baker", "Judi Dench", "Gottfried John", "Robbie Coltrane", "Alan Cumming", "Tcheky Karyo", "Desmond Llewelyn", "Samantha Bond", "Michael Kitchen", "Simon Kunz", "Billy J. Mitchell", "Constantine Gregory", "Minnie Driver", "Michelle Arthur", "Ravil Isyanov")));
    ArrayList<Ratable> items2 = new ArrayList<>(Arrays.asList(song5,song6,mov4,song7,mov5));
    Movie mov7 = new Movie("Balto",new ArrayList<>(Arrays.asList("Kevin Bacon","Bob Hoskins","Bridget Fonda","Jim Cummings","Jack Angel","Danny Mann","Robbie Rist","Frank Welker","Miriam Margolyes")));
    Song song8 = new Song("Sunflower","Post Malone","3KkXRkHbMCARz0aVfEt68P");
    Song song9 = new Song("Barricades","Hiroyuki Sawano","6iaQi9uPzHoXLMo5g490Bj");
    Song song10 = new Song("Dragonball Durag","Thundercat","62PclpoBFLl50PJpiJA5RT");
    Movie mov8 = new Movie("Dracula: Dead and Loving It",new ArrayList<>(Arrays.asList("Leslie Nielsen","Mel Brooks","Amy Yasbeck","Peter MacNicol","Harvey Korman","Steven Weber","Megan Cavanagh","Gregg Binkley","Anne Bancroft")));
    Movie mov9 = new Movie("Cutthroat Island",new ArrayList<>(Arrays.asList("Geena Davis","Matthew Modine","Frank Langella","Maury Chaykin","Patrick Malahide","Stan Shaw","Rex Linn","Paul Dillon","Christopher Masterson","Harris Yulin","Angus Wright","Richard Leaf","Rupert Vansittart","Nick Bartlett","David Bailie","Christopher Adamson")));
    ArrayList<Ratable> items3 = new ArrayList<>(Arrays.asList(mov7,song8,song9,song10,mov8,mov9));
    MediaLibrary lib1 = new MediaLibrary();
    MediaLibrary lib2 = new MediaLibrary();
    MediaLibrary lib3 = new MediaLibrary();
    @Test
    public void testTopKRatables(){
        lib1.populateLibrary("data/songs1.csv","data/movies1.csv","data/movieRatings2.csv");
        lib2.populateLibrary("data/songs2.csv","data/movies2.csv","data/movieRatings2.csv");
        lib3.populateLibrary("data/songs3.csv","data/movies3.csv","data/movieRatings2.csv");
        assertTrue("error in topKRatables() test 1",compareRatableArrayLists(lib1.topKRatables(10),items1));
        assertTrue("error in topKRatables() test 2",compareRatableArrayLists(lib2.topKRatables(5),items2));
        assertTrue("error in topKRatables() test 3",compareRatableArrayLists(lib3.topKRatables(6),items3));
    }
}