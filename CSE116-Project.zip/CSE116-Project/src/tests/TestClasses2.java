package tests;

import org.junit.Test;
import ratings.Movie;
import ratings.Rating;
import ratings.Song;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;

public class TestClasses2 {
    public static boolean compareArrayListsIgnoreCase(ArrayList<String> a, ArrayList<String> b){
        if(a.size() == b.size()){
            for(int i = 0;i<a.size();i++){
                if(0 != a.get(i).compareToIgnoreCase(b.get(i))){
                   return false;
                }
            }
        }else{
            return false;
        }
        return true;
    }
    ArrayList<String> cast1 = new ArrayList<>(Arrays.asList("Miley Cyrus","John Travolta","Susie Essman", "Mark Walton"));
    ArrayList<String> cast2 = new ArrayList<>(Arrays.asList("Leonardo DiCaprio","Kate Winslet","Billy Zane", "Kathy Bates"));
    ArrayList<String> cast3 = new ArrayList<>(Arrays.asList("Dwayne Johnson","Jack Black","Kevin Hart", "Karen Gillian"));
    Movie mov1 = new Movie("Bolt",cast1);
    Movie mov2 = new Movie("Titanic",cast2);
    Movie mov3 = new Movie("Jumanji",cast3);
    Song song1 = new Song("Reminder","The Weeknd","Starboy4");
    Song song2 = new Song("I KNOW?","Travis Scott","UTOPIA10");
    Song song3 = new Song("Champion","Kanye West","Graduation2");
    Song song4 = new Song("Burn","¥$","VULTURES19");
    Song song5 = new Song("Where My Twin @","Future","WE_DON'T_TRUST_YOU17");
    Song song6 = new Song("Man On The Moon","Kid Cudi","Man_On_The_Moon:_The_End_Of_Day16");
    Rating rat1 = new Rating("MusicLover123",4);
    Rating rat2 = new Rating("SongText123",1);
    Rating rat3 = new Rating("PopOnline42",2);
    Rating rat4 = new Rating("NightMusic88",1);
    Rating rat5 = new Rating("RockGuitar777",5);
    Rating rat6 = new Rating("AudioNews808",4);
    Rating rat7 = new Rating("FreshTunes2023",3);
    Rating rat8 = new Rating("NerdsInHoodies13",5);
    Rating rat9 = new Rating("GrooveMaster808",2);
    Rating rat10 = new Rating("LyricLover13",3);
    Rating rat11 = new Rating("BeatMusic42",5);
    Rating rat12 = new Rating("RhythmRebel99",4);
    Rating rat91 = new Rating("GrooveMaster808",20);
    Rating rat101 = new Rating("LyricLover13",-5);

    @Test
    public void testGetCast(){
        assertTrue(compareArrayListsIgnoreCase(mov1.getCast(),cast1));
        assertTrue(compareArrayListsIgnoreCase(mov2.getCast(),cast2));
        assertTrue(compareArrayListsIgnoreCase(mov3.getCast(),cast3));
    }
    @Test
    public void MovieBayesianAverageRating(){
        mov1.addRating(rat1);
        mov1.addRating(rat2);
        mov1.addRating(rat3);
        mov1.addRating(rat4);
        mov2.addRating(rat5);
        mov2.addRating(rat6);
        mov2.addRating(rat7);
        mov2.addRating(rat8);
        mov3.addRating(rat9);
        mov3.addRating(rat10);
        mov3.addRating(rat11);
        mov3.addRating(rat12);
        assertEquals("error in averageRating() test 1",2.33,mov1.bayesianAverageRating(2,3),0.01);
        assertEquals("error in averageRating() test 2",3.83,mov2.bayesianAverageRating(2,3),0.01);
        assertEquals("error in averageRating() test 3",3.33,mov3.bayesianAverageRating(2,3),0.01);
    }
    @Test
    public void SongBayesianAverageRating(){
        song1.addRating(rat1);
        song1.addRating(rat2);
        song1.addRating(rat3);
        song1.addRating(rat4);
        song2.addRating(rat5);
        song2.addRating(rat6);
        song2.addRating(rat7);
        song2.addRating(rat8);
        song3.addRating(rat91);
        song3.addRating(rat101);
        song3.addRating(rat11);
        song3.addRating(rat12);
        song5.addRating(rat1);
        song6.addRating(rat1);
        assertEquals("error in averageRating() test 1",2.33,song1.bayesianAverageRating(2,3),0.01);
        assertEquals("error in averageRating() test 2",3.83,song2.bayesianAverageRating(2,3),0.01);
        assertEquals("error in averageRating() test 3",3.75,song3.bayesianAverageRating(2,3),0.01);
        assertEquals("error in averageRating() test 4",3,song4.bayesianAverageRating(2,3),0.01);
        assertEquals("error in averageRating() test 5",4.0,song5.bayesianAverageRating(0,3),0.01);
        assertEquals("error in averageRating() test 6",0.0,song6.bayesianAverageRating(3,20),0.01);
    }
}
