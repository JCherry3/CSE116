package tests;

import org.junit.Test;
import static org.junit.Assert.*;
import ratings.Song;
import ratings.Playlist;
import ratings.datastructures.BinaryTreeNode;
import ratings.datastructures.LinkedListNode;
import ratings.datastructures.SongTitleComparator;
import java.util.ArrayList;
import java.util.Arrays;
import static tests.TestClasses1.*;
import static tests.TestDataStructures1.*;

public class TestDataStructures2 {
    public static LinkedListNode<Song> getSongList(BinaryTreeNode<Song> root){
        if(root == null){
            return null;
        }
        LinkedListNode<Song> out = new LinkedListNode<>(null,null);
        LinkedListNode<Song> tmpout = new LinkedListNode<>(null,null);
        if(root.getLeft() != null){
            tmpout = out;
            while(tmpout.getNext() != null){
                tmpout = tmpout.getNext();
            }
            tmpout.setNext(getSongList(root.getLeft()));
        }
        if(out == null){
            out = new LinkedListNode<>(root.getValue(),null);
        }else{
            tmpout = out;
            while(tmpout.getNext() != null){
                tmpout = tmpout.getNext();
            }
            tmpout.setNext(new LinkedListNode<Song>(root.getValue(),null));
        }
        if(root.getRight() != null){
            tmpout = out;
            while(tmpout.getNext() != null){
                tmpout = tmpout.getNext();
            }
            tmpout.setNext(getSongList(root.getRight()));
        }
        out = out.getNext();
        return out;
    }
    public static boolean compareSongTrees(BinaryTreeNode<Song> tree1,BinaryTreeNode<Song> tree2){
        LinkedListNode<Song> list1 = getSongList(tree1);
        LinkedListNode<Song> list2 = getSongList(tree2);
        if(list1 == null ^ list2 == null){
            return false;
        }
        if(list1 == null && list2 == null){
            return true;
        }
        boolean comp1;
        boolean comp2;
        LinkedListNode<Song> tmpl1 = list1;
        LinkedListNode<Song> tmpl2 = list2;
        int size1 = 0;
        int size2 = 0;
        while(tmpl1.getNext() != null){
            size1++;
            tmpl1 = tmpl1.getNext();
        }
        while(tmpl2.getNext() != null){
            size2++;
            tmpl2 = tmpl2.getNext();
        }
        if(size1 != size2){
            return false;
        }
        while(list1.getNext() != null){
            comp1 = compareSongs(list1.getValue(),list2.getValue());
            comp2 = compareListsOfRatings(list1.getValue().getRatings(),list2.getValue().getRatings());
            if(!comp1 || !comp2){
                return false;
            }
            else{
                list1 = list1.getNext();
                list2 = list2.getNext();
            }
        }
        comp1 = compareSongs(list1.getValue(),list2.getValue());
        comp2 = compareListsOfRatings(list1.getValue().getRatings(),list2.getValue().getRatings());
        if(!comp1 || !comp2){
            return false;
        }
        return true;
    }
//    public static boolean compareListsOfSongs(LinkedListNode<Song> node1,LinkedListNode<Song> node2){
//        if(node1 == null && node2 == null){
//            return true;
//        }
//        if(node1 == null || node2 == null){
//            return false;
//        }
//        if(node1.getNext() == null && node2.getNext() == null){
//            if(compareSongs(node1.getValue(),node2.getValue()) && compareListsOfRatings(node1.getValue().getRatings(),node2.getValue().getRatings())){
//                return true;
//            }else{
//                return false;
//            }
//        }if(node1.getNext() == null || node2.getNext() == null){
//            return false;
//        }
//        if(compareSongs(node1.getValue(),node2.getValue()) && compareListsOfRatings(node1.getValue().getRatings(),node2.getValue().getRatings())){
//            return compareListsOfSongs(node1.getNext(),node2.getNext());
//        }else{
//            return false;
//        }
//    }
//    public static boolean compareListsOfSongs(LinkedListNode<Song> list1,LinkedListNode<Song> list2){
//        if(list1 == null && list2 == null){
//            return true;
//        }
//        if(list1 == null || list2 == null){
//            return false;
//        }
//        boolean comp1;
//        boolean comp2;
//        LinkedListNode<Song> tmpl1 = list1;
//        LinkedListNode<Song> tmpl2 = list2;
//        int size1 = 0;
//        int size2 = 0;
//        while(tmpl1.getNext() != null){
//            size1++;
//            tmpl1 = tmpl1.getNext();
//        }
//        while(tmpl2.getNext() != null){
//            size2++;
//            tmpl2 = tmpl2.getNext();
//        }
//        if(size1 != size2){
//            return false;
//        }
//        while(list1.getNext() != null){
//            comp1 = compareSongs(list1.getValue(),list2.getValue());
//            comp2 = compareListsOfRatings(list1.getValue().getRatings(),list2.getValue().getRatings());
//            if(!comp1 || !comp2){
//                return false;
//            }
//            else{
//                list1 = list1.getNext();
//                list2 = list2.getNext();
//            }
//        }
//        comp1 = compareSongs(list1.getValue(),list2.getValue());
//        comp2 = compareListsOfRatings(list1.getValue().getRatings(),list2.getValue().getRatings());
//        if(!comp1 || !comp2){
//            return false;
//        }
//        return true;
//    }
    public static boolean compareListsOfSongs(LinkedListNode<Song> list1,LinkedListNode<Song> list2){
        LinkedListNode<Song> tmp1 = list1;
        LinkedListNode<Song> tmp2 = list2;
        if(tmp1 == null && tmp2 == null){
            return true;
        }
        if(tmp1 == null || tmp2 == null){
            return false;
        }
        if(tmp1.size() == tmp2.size()){
            while(tmp1.getNext() != null){
                if(!compareSongs(tmp1.getValue(),tmp2.getValue())){
                    return false;
                }
                tmp1 = tmp1.getNext();
                tmp2 = tmp2.getNext();
            }
        }else{
            return false;
        }
        return compareSongs(tmp1.getValue(),tmp2.getValue());
    }
    SongTitleComparator comp = new SongTitleComparator();
    Playlist playlist1 = new Playlist(comp);
    Playlist playlist2 = new Playlist(comp);
    Playlist playlist3 = new Playlist(comp);
    Playlist playlist4 = new Playlist(comp);
    Playlist testPlaylist1 = new Playlist(comp);
    Playlist testPlaylist2 = new Playlist(comp);
    Playlist testPlaylist3 = new Playlist(comp);
    Playlist testPlaylist4 = new Playlist(comp);
    Song song1 = new Song("Reminder","The Weeknd","Starboy_4");
    Song song2 = new Song("I KNOW?","Travis Scott","UTOPIA_10");
    Song song3 = new Song("Champion","Kanye West","Graduation_2");
    Song song4 = new Song("Burn","¥$","VULTURES_19");
    Song song5 = new Song("Where My Twin @","Future","WE_DON'T_TRUST_YOU_17");
    Song song6 = new Song("Man On The Moon","Kid Cudi","Man_On_The_Moon:_The_End_Of_Day_16");
    Song song7 = new Song("Sky","Playboi Carti","Whole_Lotta_Red_19");
    Song song8 = new Song("Fire","KIDS SEE GHOSTS","KIDS_SEE_GHOSTS_2");
    Song song9 = new Song("Myron","Lil Uzi Vert","LUV_vs._The_World_2_1");
    Song song10 = new Song("Breathe","Yeat","2093_3");
    Song song11 = new Song("Bad Man","Polo G","Hall_of_Fame_2.0_1");
    Song song12 = new Song("née-nah","21 Savage","american_dream_9");
    Song song13 = new Song("Secrets","A Boogie Wit da Hoodie","Artist_2.0_5");
    Song song14 = new Song("Senior Skip Day","Mac Miller","K.I.D.S_5");
    Song song15 = new Song("Alone","Scorey","Help_Is_On_The_Way_1");
    Song song16 = new Song("Breakin Bad","Sleepy Hallow","DON'T_SLEEP_3");
    Song song17 = new Song("Wet Dreamz","J. Cole","2014_Forest_Hills_Drive_3");
    Song song18 = new Song("family ties","Baby Keem","The_Melodic_Blue_10");
    Song song19 = new Song("Life Goes On","Lil Baby","Harder_Than_Ever_13");
    Song song20 = new Song("Empty","Juice WRLD","Death_Race_For_love_1");
    Song song21 = new Song("Camelot","NLE Choppa","Top_Shotta_5");
    ArrayList<Song> list1 = new ArrayList<>(Arrays.asList(song1,song2,song3,song4,song5,song6,song7));
    ArrayList<Song> list2 = new ArrayList<>(Arrays.asList(song8,song9,song10,song11,song12,song13,song14));
    ArrayList<Song> list3 = new ArrayList<>(Arrays.asList(song15,song16,song17,song18,song19,song20,song21));
    @Test
    public void testGetSongTree(){
        LinkedListNode<Song> tList1 = new LinkedListNode<>(song4,null);
        tList1.append(song3);
        tList1.append(song2);
        tList1.append(song6);
        tList1.append(song1);
        tList1.append(song7);
        tList1.append(song5);
        LinkedListNode<Song> tList2 = new LinkedListNode<>(song11,null);
        tList2.append(song10);
        tList2.append(song8);
        tList2.append(song9);
        tList2.append(song12);
        tList2.append(song13);
        tList2.append(song14);
        LinkedListNode<Song> tList3 = new LinkedListNode<>(song15,null);
        tList3.append(song16);
        tList3.append(song21);
        tList3.append(song20);
        tList3.append(song18);
        tList3.append(song19);
        tList3.append(song17);
        for (Song song : list1) {
            playlist1.addSong(song);
        }
        for (Song song : list2) {
            playlist2.addSong(song);
        }
        for (Song song : list3) {
            playlist3.addSong(song);
        }
        for(int a=list1.size()-1;a>=0;a--){
            testPlaylist1.addSong(list1.get(a));
        }
        for(int b=list2.size()-1;b>=0;b--){
            testPlaylist2.addSong(list2.get(b));
        }
        for(int c=list3.size()-1;c>=0;c--){
            testPlaylist3.addSong(list3.get(c));
        }
        assertTrue(compareSongTrees(playlist1.getSongTree(),testPlaylist1.getSongTree()));
        assertTrue(compareSongTrees(playlist2.getSongTree(),testPlaylist2.getSongTree()));
        assertTrue(compareSongTrees(playlist3.getSongTree(),testPlaylist3.getSongTree()));
        assertTrue(compareSongTrees(playlist4.getSongTree(),testPlaylist4.getSongTree()));
    }
    @Test
    public void testGetSongList(){
        LinkedListNode<Song> tList1 = new LinkedListNode<>(song4,null);
        tList1.append(song3);
        tList1.append(song2);
        tList1.append(song6);
        tList1.append(song1);
        tList1.append(song7);
        tList1.append(song5);
        LinkedListNode<Song> tList2 = new LinkedListNode<>(song11,null);
        tList2.append(song10);
        tList2.append(song8);
        tList2.append(song9);
        tList2.append(song12);
        tList2.append(song13);
        tList2.append(song14);
        LinkedListNode<Song> tList3 = new LinkedListNode<>(song15,null);
        tList3.append(song16);
        tList3.append(song21);
        tList3.append(song20);
        tList3.append(song18);
        tList3.append(song19);
        tList3.append(song17);
        for (Song song : list1) {
            playlist1.addSong(song);
        }
        for (Song song : list2) {
            playlist2.addSong(song);
        }
        for (Song song : list3) {
            playlist3.addSong(song);
        }
        assertTrue(compareListsOfSongs(playlist1.getSongList(),tList1));
        assertTrue(compareListsOfSongs(playlist2.getSongList(),tList2));
        assertTrue(compareListsOfSongs(playlist3.getSongList(),tList3));
    }
}
