package ratings.datastructures;

import ratings.Movie;

public class MovieBayesianRatingComparator extends Comparator<Movie>{
    @Override
    public boolean compare(Movie a, Movie b){
        return a.bayesianAverageRating(2,3) > b.bayesianAverageRating(2,3);
    }
}
