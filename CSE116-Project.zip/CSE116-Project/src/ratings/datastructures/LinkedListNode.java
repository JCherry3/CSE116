package ratings.datastructures;
import ratings.Rating;
public class LinkedListNode<T> {

    private T value;
    private LinkedListNode<T> next;

    public LinkedListNode(T val, LinkedListNode<T> next) {
        this.value = val;
        this.next = next;
    }

    public T getValue() {
        return this.value;
    }

    public void setNext(LinkedListNode<T> node) {
        this.next = node;
    }

    public LinkedListNode<T> getNext() {
        return this.next;
    }

    public int size() {
        if (this.next == null) {
            return 1;
        } else {
            return 1 + this.next.size();
        }
    }
    public void append(T value) {
        if (this.next == null) {
            this.next = new LinkedListNode<>(value, null);
        } else {
            this.next.append(value);
        }
    }
    public String toString() {
        String out = "";
        out += this.value.toString();
        if (this.next != null) {
            out += " " + this.next.toString();
        }
        return out;
    }
    public void add(LinkedListNode<T> node){
        if(this.next != null){
            this.next.add(node);
        }else{
            this.setNext(node);
        }
    }
    public boolean equals(LinkedListNode<T> node){
        LinkedListNode<T> tmp = new LinkedListNode<T>(this.value,this.next);
        if(tmp.size() != node.size()){
            return false;
        }
        while(tmp.next != null){
            if(!tmp.value.equals(node.value)){
                return false;
            }
            tmp = tmp.next;
            node = node.next;
        }
        return true;
    }
}