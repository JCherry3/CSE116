package ratings.datastructures;

import ratings.Movie;

public class MovieTitleComparator extends Comparator<Movie>{
    @Override
    public boolean compare(Movie a, Movie b) {
        return 0>a.getTitle().compareToIgnoreCase(b.getTitle());
    }
}
