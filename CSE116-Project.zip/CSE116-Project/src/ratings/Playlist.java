package ratings;

import ratings.datastructures.*;

public class Playlist {
    private Comparator<Song> comp;
    private BinaryTreeNode<Song> playlist;
    public Playlist(Comparator<Song> songComp){
        this.comp = songComp;
        this.playlist = null;
    }
    public void addSong(Song song){
        if (this.playlist == null) {
            this.playlist = new BinaryTreeNode<>(song,null,null);
        } else {
            this.insertHelper(this.playlist,song);
        }
    }
    private void insertHelper(BinaryTreeNode<Song> node, Song toInsert) {
        if (this.comp.compare(toInsert, node.getValue())) {
            if (node.getLeft() == null) {
                node.setLeft(new BinaryTreeNode<>(toInsert, null, null));
            } else {
                insertHelper(node.getLeft(), toInsert);
            }
        } else {
            if (node.getRight() == null) {
                node.setRight(new BinaryTreeNode<>(toInsert, null, null));
            } else {
                insertHelper(node.getRight(), toInsert);
            }
        }
    }
    public BinaryTreeNode<Song> getSongTree(){
        return this.playlist;
    }
    public static LinkedListNode<Song> getSongList(BinaryTreeNode<Song> root){
        if(root == null){
            return null;
        }
        LinkedListNode<Song> out = new LinkedListNode<>(null,null);
        if(root.getLeft() != null){
            out.add(getSongList(root.getLeft()));
        }
        if(out == null){
            out = new LinkedListNode<>(root.getValue(),null);
        }else{
            out.append(root.getValue());
        }
        if(root.getRight() != null){
            out.add(getSongList(root.getRight()));
        }
        out = out.getNext();
        return out;
    }
    public LinkedListNode<Song> getSongList(){
        return getSongList(this.playlist);
    }
}
