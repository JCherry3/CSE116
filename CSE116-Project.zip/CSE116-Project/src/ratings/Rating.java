package ratings;

public class Rating {
    private String reviewerID;
    private int review;
    public Rating(String id, int review){
        this.reviewerID =id;
        if(review > 5){
            this.review = -1;
        } else if(review < 1){
            this.review = -1;
        } else{
            this.review = review;
        }
    }
    public String getReviewerID(){
        return this.reviewerID;
    }
    public void setReviewerID(String newRevID){
        this.reviewerID = newRevID;
    }
    public int getRating(){
        return this.review;
    }
    public void setRating(int newRat){
        if(newRat > 5){
            this.review = -1;
        } else if(newRat < 1){
            this.review = -1;
        } else{
            this.review = newRat;
        }
    }
    public String toString(){
        String out = "";
        out += this.getReviewerID();
        out += ", ";
        out += this.getRating();
        out += "";
        return out;
    }
    public boolean equals(Rating r2){
        boolean b5 = (this.getReviewerID().equals(r2.getReviewerID()));
        boolean b6 = (this.getRating() == r2.getRating());
        if(b5 && b6){
            return true;
        }
        return false;
    }
}
