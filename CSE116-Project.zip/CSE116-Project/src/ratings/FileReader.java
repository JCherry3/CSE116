package ratings;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;

public class FileReader {
    public static ArrayList<String> readFile(String filename) {
        try {
            return new ArrayList<>(Files.readAllLines(Paths.get(filename)));
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }
    public static ArrayList<ArrayList<String>> splitCSV(ArrayList<String> list){
        ArrayList<ArrayList<String>> splits = new ArrayList<>();
        for(String line : list){
            ArrayList<String> split = new ArrayList<>(Arrays.asList(line.split(",")));
            splits.add(split);
        }
        return splits;
    }
    public static ArrayList<Song> readSongs(String filename){
        ArrayList<ArrayList<String>> lines = splitCSV(readFile(filename));
        ArrayList<Song> songs = new ArrayList<>();
        if(lines.isEmpty()){
            return songs;
        }
        boolean exists;
        int location = 0;
        int acc;
        for(ArrayList<String> line : lines){
            exists = false;
            acc = 0;
            for(Song song : songs){
                if(song.getTitle().equals(line.get(2))){
                    exists = true;
                    location = acc;
                }
                acc++;
            }
            if(exists){
                songs.get(location).addRating(new Rating(line.get(3),Integer.parseInt(line.get(4))));
            }else {
                Song newSong = new Song(line.get(2), line.get(1), line.get(0));
                newSong.addRating(new Rating(line.get(3), Integer.parseInt(line.get(4))));
                songs.add(newSong);
            }
        }
        return songs;
    }
    public static ArrayList<Movie> readMovies(String filename){
        ArrayList<ArrayList<String>> lines = splitCSV(readFile(filename));
        ArrayList<Movie> movies = new ArrayList<>();
        if(lines.isEmpty()){
            return movies;
        }
        for(ArrayList<String> line : lines) {
            ArrayList<String> cast = new ArrayList<>();
            for (int i = 1; i < line.size(); i++) {
                cast.add(line.get(i));
            }
            movies.add(new Movie(line.get(0), cast));
        }
        return movies;
    }
    public static ArrayList<Movie> readMovieRatings(ArrayList<Movie> movies, String filename){
        ArrayList<ArrayList<String>> lines = splitCSV(readFile(filename));
        ArrayList<Movie> out = new ArrayList<>();
        if(lines.isEmpty()){
            return out;
        }
        int acc;
        int location = 0;
        boolean exists = false;
        for(ArrayList<String> line : lines){
            acc = 0;
            exists = false;
            for(Movie movie : movies){
                if(movie.getTitle().equals(line.get(0))){
                    exists = true;
                    location = acc;
                }
                acc++;
            }
            if(exists){
                movies.get(location).addRating(new Rating(line.get(1),Integer.parseInt(line.get(2))));
            }
        }
        for(Movie mov : movies){
            if(mov.getRatings() != null){
                out.add(mov);
            }
        }
        return out;
    }
}
