package ratings;

public class Reviewer {
    private String reviewerID;
    public Reviewer(String newReverID){
        this.reviewerID = newReverID;
    }
    public String getReviewerID(){
        return this.reviewerID;
    }
    public void setReviewerID(String newid){
        this.reviewerID = newid;
    }
    public Rating rateSong(int rate){
        return new Rating(reviewerID,rate);
    }
    public String toString(){
        return this.getReviewerID();
    }
}
