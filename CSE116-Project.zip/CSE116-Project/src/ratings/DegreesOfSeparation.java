package ratings;

import java.util.ArrayList;
import java.util.HashMap;

import static ratings.FileReader.readMovies;

public class DegreesOfSeparation {
    private ArrayList<Movie> movies;
    public DegreesOfSeparation(ArrayList<Movie> movs){
        this.movies = movs;
    }
    public ArrayList<Movie> getMovies() {
        return movies;
    }
    private static HashMap<String,ArrayList<String>> graphIt(ArrayList<Movie> movies){
        HashMap<String,ArrayList<String>> graph = new HashMap<>();
        for(Movie movie : movies){
            for(String actor : movie.getCast()){
                ArrayList<String> people = new ArrayList<>();
                for(String person : movie.getCast()){
                    if(!person.equals(actor)){
                        people.add(person);
                    }
                }
                if(graph.containsKey(actor)){
                    graph.get(actor).addAll(people);
                }else{
                    graph.put(actor,people);
                }
            }
        }
        return graph;
    }
    public int degreesOfSeparation(String actor1,String actor2){
        HashMap<String,ArrayList<String>> map = graphIt(this.movies);
        if(actor1.equals(actor2)){
            return 0;
        }
        if(!map.containsKey(actor1) || !map.containsKey(actor2)){
            return -1;
        }
        ArrayList<String> stack = new ArrayList<>();
        HashMap<String,Integer> track = new HashMap<>();
        track.put(actor1,0);
        stack.add(actor1);
        int num = 0;
        int acc = 0;
        String member = "";
        while(!stack.isEmpty()){
            member = stack.remove(0);
            acc = track.get(member);
            num = acc + 1;
            for(String actor : map.getOrDefault(member,new ArrayList<>())){
                if(actor.equals(actor2)){
                    return num;
                }
                if(!track.containsKey(actor)){
                    track.put(actor,num);
                    stack.add(actor);
                }
            }
        }
        return -1;
    }
    public static void main(String args[]){
        DegreesOfSeparation bacon = new DegreesOfSeparation(readMovies("data/movies.csv"));
        int num = bacon.degreesOfSeparation("Bette Midler","Kanji Tsuda");
        System.out.println(num);
    }
}
