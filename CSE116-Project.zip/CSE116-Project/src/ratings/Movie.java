package ratings;

import java.util.ArrayList;

public class Movie extends Ratable{
    private ArrayList<String> cast;

    public Movie(String title,ArrayList<String> cast){
        super(title);
        this.cast = cast;
    }
    public ArrayList<String> getCast(){
        return this.cast;
    }
    public String toString(){
        String out = "{";
        out += this.getTitle();
        for(String actor : this.getCast()){
            out += ", ";
            out += actor;
        }
        out += "}";
        return out;
    }
}
