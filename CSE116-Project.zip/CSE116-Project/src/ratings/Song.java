package ratings;
import ratings.datastructures.LinkedListNode;
import static tests.TestDataStructures1.*;

public class Song extends Ratable{
    private String artist;
    private String songID;
    public Song(String title, String artist, String songID){
        super(title);
        this.artist = artist;
        this.songID = songID;
    }
    public String getArtist(){
        return this.artist;
    }
    public void setArtist(String newArtist){
        this.artist = newArtist;
    }
    public String getSongID(){
        return this.songID;
    }
    public void setSongID(String newID){
        this.songID = newID;
    }
    public String toString(){
        String out = "{";
        out += this.getTitle();
        out += ", ";
        out += this.getArtist();
        out += ", ";
        out += this.getSongID();
        out += "}";
        return out;
    }
    public boolean equals(Song song){
        if(this.getTitle() == song.getTitle() && this.artist == song.artist && this.songID == song.songID){
            return compareListsOfRatings(this.getRatings(),song.getRatings());
        }
        return false;
    }
}
