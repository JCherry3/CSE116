package ratings;

import java.util.ArrayList;
import static ratings.FileReader.*;
public class MediaLibrary {
    private ArrayList<Song> songs;
    private ArrayList<Movie> movies;
    public MediaLibrary(){}
    public void populateLibrary(String songfile, String moviefile, String movRatsfile){
        this.songs = readSongs(songfile);
        this.movies = readMovieRatings(readMovies(moviefile),movRatsfile);
    }
    public ArrayList<Ratable> topKRatables(int k){
        ArrayList<Ratable> library = new ArrayList<>();
        ArrayList<Ratable> top = new ArrayList<>();
        ArrayList<Ratable> topk = new ArrayList<>();
        boolean added = false;
        library.addAll(this.songs);
        library.addAll(this.movies);;
        top.add(library.get(0));
        for(int i=1;i<library.size();i++){
            added = false;
            for(int x=0;x<top.size();x++){
                if(x == 0){
                    if(added) break;
                    if(library.get(i).bayesianAverageRating(2,3) >= top.get(x).bayesianAverageRating(2,3)){
                        top.add(x,library.get(i));
                        added = true;
                    }
                    if(added){
                        break;
                    }
                    if(top.size() == 1 && library.get(i).bayesianAverageRating(2,3) <= top.get(x).bayesianAverageRating(2,3)){
                        top.add(library.get(i));
                        added = true;
                    }else if(top.get(x).bayesianAverageRating(2,3) >= library.get(i).bayesianAverageRating(2,3) && top.get(x+1).bayesianAverageRating(2,3)<= library.get(i).bayesianAverageRating(2,3)){
                        top.add(x+1,library.get(i));
                        added = true;
                    }
                    if(added){
                        break;
                    }
                }else if(x == top.size()-1){
                    if(library.get(i).bayesianAverageRating(2,3) <= top.get(x).bayesianAverageRating(2,3)){
                        top.add(library.get(i));
                        added = true;
                    }
                    if(added){
                        break;
                    }
                }else if(top.get(x).bayesianAverageRating(2,3) >= library.get(i).bayesianAverageRating(2,3) && top.get(x+1).bayesianAverageRating(2,3) <= library.get(i).bayesianAverageRating(2,3)){
                    top.add(x+1,library.get(i));
                    break;
                }
            }
        }
        if(k > top.size()){
            return top;
        }
        for(int y=0;y<k;y++){
            topk.add(top.get(y));
        }
        return topk;
    }
    public static void main(String args[]){
        MediaLibrary lib1 = new MediaLibrary();
        MediaLibrary lib2 = new MediaLibrary();
        MediaLibrary lib3 = new MediaLibrary();
        lib1.populateLibrary("data/songs1.csv","data/movies1.csv","data/movieRatings2.csv");
        lib2.populateLibrary("data/songs2.csv","data/movies2.csv","data/movieRatings2.csv");
        lib3.populateLibrary("data/songs3.csv","data/movies3.csv","data/movieRatings2.csv");
        System.out.println(lib1.topKRatables(50));
        System.out.println("\n");
        System.out.println(lib2.topKRatables(50));
        System.out.println("\n");
        System.out.println(lib3.topKRatables(50));
    }
}
