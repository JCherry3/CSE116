package ratings;

import ratings.datastructures.LinkedListNode;
import java.util.ArrayList;

public class Ratable {
    private String title;
    private LinkedListNode<Rating> ratings;
    public Ratable(String title){
        this.title = title;
    }

    public String getTitle(){
        return this.title;
    }
    public void setTitle(String newTitle){
        this.title = newTitle;
    }
    public void addRating(Rating rat){
        if(this.ratings == null){
            this.ratings = new LinkedListNode<>(rat,null);
        }else{
            this.ratings.append(rat);
        }
    }
    public LinkedListNode<Rating> getRatings() {
        return this.ratings;
    }
    public void setRatings(LinkedListNode<Rating> ratings) {
        this.ratings = ratings;
    }
    public double averageRating(){
        if(this.ratings == null){
            return 0.0;
        }
        LinkedListNode<Rating> temp = this.getRatings();
        int total = 0;
        double i = 0;
        while(temp.getNext() != null){
            Rating tmprt = temp.getValue();
            int val = tmprt.getRating();
            if(val != -1){
                total += val;
                i += 1.0;
            }
            temp = temp.getNext();
        }
        Rating tmprt = temp.getValue();
        int val = tmprt.getRating();
        if(val != -1){
            total += val;
            i += 1.0;
        }
        return total/i;
    }
    public void removeRatingByReviewer(Reviewer rev){
        if(this.ratings == null){
            return;
        }
        String id = rev.getReviewerID();
        LinkedListNode<Rating> temp = this.ratings;
        if(temp.getValue().getReviewerID() == id){
            this.ratings = temp.getNext();
            return;
        }
        while(temp.getNext() != null){
            if(temp.getNext().getValue().getReviewerID() == id){
                temp.setNext(temp.getNext().getNext());
                return;
            }
            temp = temp.getNext();
        }
    }
    public double bayesianAverageRating(int ext,int valext){
        if(valext < 1 || valext > 5 || ext < 0){
            return 0.0;
        }
        if(this.ratings == null && ext > 0){
            return valext;
        }
        if(ext == 0){
            return this.averageRating();
        }
        int total = valext*ext;
        double i = ext;
        LinkedListNode<Rating> temp = this.getRatings();
        while(temp.getNext() != null){
            Rating tmprt = temp.getValue();
            int val = tmprt.getRating();
            if(val != -1){
                total += val;
                i += 1.0;
            }
            temp = temp.getNext();
        }
        Rating tmprt = temp.getValue();
        int val = tmprt.getRating();
        if(val != -1){
            total += val;
            i += 1.0;
        }
        return total/i;
    }
    public String printRatings(){
        String out = "";
        LinkedListNode<Rating> rats = this.getRatings();
        while(rats.getNext() != null){
            out+= rats.getValue().toString();
            out+="\r\n";
            rats = rats.getNext();
        }
        out+= rats.getValue().toString();
        return out;
    }
}
