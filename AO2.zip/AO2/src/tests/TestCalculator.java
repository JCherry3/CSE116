package tests;

import org.junit.Test;
import calculator.model.Calculator;
import static org.junit.Assert.*;

public class TestCalculator {
    Calculator calc = new Calculator();
    @Test
    public void testSetup(){
        assertEquals("Error in setup",0.0,calc.displayNumber(),0.001);
    }
    @Test
    public void testNumbersAndDecimals(){
        calc.numberPressed(3);
        assertEquals("Error in numberPressed() test 1",3.0,calc.displayNumber(),0.001);
        calc.numberPressed(5);
        assertEquals("Error in numberPressed() test 2",35.0,calc.displayNumber(),0.001);
        calc.numberPressed(1);
        assertEquals("Error in numberPressed() test 3",351.0,calc.displayNumber(),0.001);
        calc.decimalPressed();
        calc.numberPressed(9);
        assertEquals("Error in decimalPressed() test 1",351.9,calc.displayNumber(),0.001);
        calc.decimalPressed();
        calc.numberPressed(7);
        assertEquals("Error in decimalPressed() test 2",351.97,calc.displayNumber(),0.001);
    }
    @Test
    public void testClearButton(){
        calc.numberPressed(2);
        calc.numberPressed(5);
        calc.clearPressed();
        assertEquals("Error in clearPressed() test 1",0.0,calc.displayNumber(),0.001);
    }
    @Test
    public void testMultiply(){
        calc.numberPressed(4);
        calc.multiplyPressed();
        calc.numberPressed(3);
        calc.equalsPressed();
        assertEquals("Error in multiplyPressed() test 1",12.0,calc.displayNumber(),0.001);
    }
    @Test
    public void testDivide(){
        calc.numberPressed(1);
        calc.numberPressed(8);
        calc.numberPressed(0);
        calc.numberPressed(0);
        calc.dividePressed();
        calc.numberPressed(6);
        calc.numberPressed(0);
        calc.equalsPressed();
        assertEquals("Error in dividePressed() test 1",30.0,calc.displayNumber(),0.001);
    }
    @Test
    public void testAdd(){
        calc.numberPressed(2);
        calc.addPressed();
        calc.numberPressed(3);
        calc.equalsPressed();
        assertEquals("Error in addPressed() test 1",5.0,calc.displayNumber(),0.001);
    }
    @Test
    public void testSubtract(){
        calc.numberPressed(2);
        calc.numberPressed(0);
        calc.numberPressed(4);
        calc.numberPressed(8);
        calc.subtractPressed();
        calc.numberPressed(1);
        calc.numberPressed(0);
        calc.numberPressed(2);
        calc.numberPressed(4);
        calc.equalsPressed();
        assertEquals("Error in subtractPressed() test 1",1024.0,calc.displayNumber(),0.001);
    }
    @Test
    public void testMultipleOperators(){
        calc.numberPressed(2);
        calc.numberPressed(5);
        calc.dividePressed();
        calc.numberPressed(5);
        calc.equalsPressed();
        calc.multiplyPressed();
        calc.numberPressed(1);
        calc.numberPressed(0);
        calc.equalsPressed();
        assertEquals("Error in multiple operators test 1",50.0,calc.displayNumber(),0.001);
    }
    @Test
    public void testMultipleEquals(){
        calc.numberPressed(6);
        calc.addPressed();
        calc.numberPressed(5);
        calc.equalsPressed();
        calc.equalsPressed();
        calc.equalsPressed();
        calc.equalsPressed();
        calc.equalsPressed();
        assertEquals("Error in multiple equals test 1",31.0,calc.displayNumber(),0.001);
        calc.clearPressed();
        calc.numberPressed(3);
        calc.multiplyPressed();
        calc.numberPressed(2);
        calc.equalsPressed();
        calc.equalsPressed();
        calc.equalsPressed();
        calc.equalsPressed();
        assertEquals("Error in multiple equals test 2",48.0,calc.displayNumber(),0.001);
    }
}
