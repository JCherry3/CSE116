package calculator.model;

import java.util.ArrayList;

public class PreEquals extends EqualState{
    @Override
    public double calculate(ArrayList<Object> eq, ArrayList<Object> preq){
        Operator op = (Operator) eq.get(1);
        double x = (double) eq.get(0);
        double y = (double) eq.get(2);
        return op.operate(x,y);
    }
}
