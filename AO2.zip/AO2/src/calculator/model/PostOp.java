package calculator.model;

import java.util.ArrayList;
import java.util.Arrays;

public class PostOp extends OperatorState{
    @Override
    public ArrayList<Object> changeOpp(Operator op, String num, double num1, double ans){
        return new ArrayList<Object>(Arrays.asList(op,num1,ans));
    }
}
