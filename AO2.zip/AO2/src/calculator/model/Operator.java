package calculator.model;

public class Operator {
    public double operate(double x,double y){
        return 0.0;
    }
}
