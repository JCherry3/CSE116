package calculator.model;

public abstract class DecimalState {
    public String addDecimal(){
        return "";
    }
}
