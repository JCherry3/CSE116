package calculator.model;

public class Aftermath extends State{
    @Override
    public String addNum(int a, String b){
        return "" + a;
    }
}
