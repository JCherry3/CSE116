package calculator.model;

import java.util.ArrayList;

public class PostEquals extends EqualState{
    @Override
    public double calculate(ArrayList<Object> eq, ArrayList<Object> preq){
        Operator op = (Operator) preq.get(1);
        double x = (double) preq.get(0);
        double y = (double) preq.get(2);
        return op.operate(x,y);
    }
}
