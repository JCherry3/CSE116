package calculator.model;

public class PostDecimal extends DecimalState{
}
