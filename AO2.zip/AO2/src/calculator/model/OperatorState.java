package calculator.model;

import java.util.ArrayList;
import java.util.Arrays;

public abstract class OperatorState {
    public ArrayList<Object> changeOpp(Operator op,String num, double num1, double ans){
        return new ArrayList<Object>(Arrays.asList(op,Double.parseDouble(num),Double.parseDouble(num)));
    }
}
