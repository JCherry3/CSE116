package calculator.model;
import calculator.model.Operator;
import java.util.ArrayList;
import java.util.Arrays;

public class Calculator {
    private String number;
    private String number2;
    private double num1;
    private double num2;
    private double ans;
    private double prenum2;
    private Operator operator;
    private State state;
    private OperatorState opstate;
    private DecimalState dstate;
    private EqualState eqState;
    private ArrayList<Object> equation;
    private ArrayList<Object> prevEquation;

    public Calculator(){
        this.operator = new Operator();
        this.number = "";
        this.number2 = "";
        this.num1 = 0;
        this.num2 = 0;
        this.ans = 0.0;
        this.prenum2 = 0;
        this.state = new Normal();
        this.opstate = new PreOp();
        this.dstate = new PreDecimal();
        this.eqState = new PreEquals();
        this.equation = new ArrayList<>();
        this.prevEquation = new ArrayList<>();
    }

    // Accessed by View. You should edit this method as you build functionality
    public double displayNumber() {
        return this.ans;
    }

    public void clearPressed() {
        this.num1 = 0;
        this.num2 = 0;
        this.number = "";
        this.ans = 0.0;
        this.number2 = "";
        this.prenum2 = 0;
        this.operator = new Operator();
        this.dstate = new PreDecimal();
        this.equation = new ArrayList<>();
        this.prevEquation = new ArrayList<>();
    }

    public void numberPressed(int number) {
        this.number = this.state.addNum(number,this.number);
        this.number2 = this.state.addNum(number,this.number2);
        this.ans = Double.parseDouble(this.number);
        this.state = new Normal();
        this.eqState = new PreEquals();
    }

    public void dividePressed() {
        Operator op = new Divide();
        ArrayList<Object> list = this.opstate.changeOpp(op,this.number,this.num1,this.ans);
        this.operator = (Operator) list.get(0);
        this.num1 = (double) list.get(1);
        this.ans = (double) list.get(2);
        this.number = "";
        this.opstate = new PostOp();
        this.dstate = new PreDecimal();
        this.equation.add(num1);
        this.number2 = "";
    }

    public void multiplyPressed() {
        Operator op = new Multiply();
        ArrayList<Object> list = this.opstate.changeOpp(op,this.number,this.num1,this.ans);
        this.operator = (Operator) list.get(0);
        this.num1 = (double) list.get(1);
        this.ans = (double) list.get(2);
        this.number = "";
        this.opstate = new PostOp();
        this.dstate = new PreDecimal();
        this.equation.add(num1);
        this.number2 = "";
    }

    public void subtractPressed() {
        Operator op = new Subtract();
        ArrayList<Object> list = this.opstate.changeOpp(op,this.number,this.num1,this.ans);
        this.operator = (Operator) list.get(0);
        this.num1 = (double) list.get(1);
        this.ans = (double) list.get(2);
        this.number = "";
        this.opstate = new PostOp();
        this.dstate = new PreDecimal();
        this.equation.add(num1);
        this.number2 = "";
    }

    public void addPressed() {
        Operator op = new Add();
        ArrayList<Object> list = this.opstate.changeOpp(op,this.number,this.num1,this.ans);
        this.operator = (Operator) list.get(0);
        this.num1 = (double) list.get(1);
        this.ans = (double) list.get(2);
        this.number = "";
        this.opstate = new PostOp();
        this.dstate = new PreDecimal();
        this.equation.add(num1);
        this.number2 = "";
    }

    public void equalsPressed() {
        this.equation.add(this.operator);
        this.num2 = Double.parseDouble(this.number);
        this.prenum2 = Double.parseDouble(this.number2);
        this.equation.add(num2);
        this.ans = eqState.calculate(this.equation,this.prevEquation);
        this.number = Double.toString(this.ans);
        this.prevEquation = new ArrayList<>(Arrays.asList(this.ans,this.operator,this.prenum2));
        this.num1 = 0;
        this.num2 = 0;
        this.state = new Aftermath();
        this.opstate = new PreOp();
        this.dstate = new PreDecimal();
        this.eqState = new PostEquals();
        this.equation = new ArrayList<>();
    }

    public void decimalPressed() {
        this.number += this.dstate.addDecimal();
        this.dstate = new PostDecimal();
    }
}
