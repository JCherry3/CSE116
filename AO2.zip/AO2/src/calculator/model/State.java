package calculator.model;

public abstract class State {
    public String addNum(int a, String b){
        return "";
    }
}
