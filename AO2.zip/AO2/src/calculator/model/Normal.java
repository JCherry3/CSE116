package calculator.model;

public class Normal extends State{
    @Override
    public String addNum(int a, String b){
        return b + a;
    }
}
