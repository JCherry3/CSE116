package calculator.model;

import java.util.ArrayList;

public abstract class EqualState {
    public double calculate(ArrayList<Object> eq, ArrayList<Object> preq){
        return 0.0;
    }
}
