package calculator.model;

public class Divide extends Operator{
    @Override
    public double operate(double x, double y){
        return (double) x/y;
    }
}
