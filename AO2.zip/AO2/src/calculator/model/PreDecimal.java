package calculator.model;

public class PreDecimal extends DecimalState{
    @Override
    public String addDecimal(){
        return ".";
    }
}
