Starter code for the Calculator project
