package tests;

import money.DebtCalculator;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.Assert.*;

public class TestMoney {
    public static boolean compareArrayListsIgnoreCase(ArrayList<String> a, ArrayList<String> b){
        if(a.size() == b.size()){
            for(int i = 0;i<a.size();i++){
                if(0 != a.get(i).compareToIgnoreCase(b.get(i))){
                    return false;
                }
            }
        }else{
            return false;
        }
        return true;
    }
    public static boolean containsArrayList(ArrayList<ArrayList<String>> listOfLists,ArrayList<String> list){
        for(ArrayList<String> check : listOfLists){
            if(compareArrayListsIgnoreCase(check,list)){
                return true;
            }
        }
        return false;
    }
    DebtCalculator calc = new DebtCalculator("data/money.csv");
    ArrayList<String> l1 = new ArrayList<>(Arrays.asList("Paul", "Jesse", "Leo"));
    ArrayList<String> l2 = new ArrayList<>(Arrays.asList("Jesse", "Leo", "Paul"));
    ArrayList<String> l3 = new ArrayList<>(Arrays.asList("Leo", "Paul", "Jesse"));
    ArrayList<ArrayList<String>> list = new ArrayList<>(Arrays.asList(l1,l2,l3));

    @Test
    public void testNetGains(){
        assertEquals("error in net gains test 1",50,calc.netGains("Paul"));
        assertEquals("error in net gains test 2",-25,calc.netGains("Jesse"));
        assertEquals("error in net gains test 3",-25,calc.netGains("Leo"));
    }
    @Test
    public void testFindCycle(){
        assertTrue(containsArrayList(list,calc.findCycle().getPeopleInCycle()) && calc.findCycle().getCycleAmount() == 50);
    }

}
