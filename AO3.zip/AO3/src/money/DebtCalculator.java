package money;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class DebtCalculator {

    private ArrayList<ArrayList<String>> records;
    private HashMap<String,HashMap<String,Integer>> graph;
    public DebtCalculator(String filename){
        this.records = splitCSV(readFile(filename));
        this.graph = graphIt(this.records);
    }

    public static ArrayList<String> readFile(String filename) {
        try {
            return new ArrayList<>(Files.readAllLines(Paths.get(filename)));
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }
    public static ArrayList<ArrayList<String>> splitCSV(ArrayList<String> list){
        ArrayList<ArrayList<String>> splits = new ArrayList<>();
        for(String line : list){
            ArrayList<String> split = new ArrayList<>(Arrays.asList(line.split(",")));
            splits.add(split);
        }
        return splits;
    }
    private static HashMap<String,HashMap<String,Integer>> graphIt(ArrayList<ArrayList<String>> records){
        HashMap<String,HashMap<String,Integer>> graph = new HashMap<>();
        for(ArrayList<String> record : records){
            if(!graph.containsKey(record.get(0))){
                graph.put(record.get(0),new HashMap<String,Integer>());
            }
            graph.get(record.get(0)).put(record.get(1),Integer.parseInt(record.get(2)));
        }
        return graph;
    }
    public int netGains(String person){
        int net = 0;
        for(ArrayList<String> record : this.records){
            if(record.get(0).equals(person)){
                net = net - Integer.parseInt(record.get(2));
            }
            if(record.get(1).equals(person)){
                net += Integer.parseInt(record.get(2));
            }
        }
        return net;
    }

    public Cycle findCycle(){
        for(String key : this.graph.keySet()){
            ArrayList<String> stack = new ArrayList<>();
            HashMap<String,Integer> track = new HashMap<>();
            ArrayList<String> debtors = new ArrayList<>();
            debtors.add(key);
            track.put(key,0);
            stack.add(key);
            int num = 0;
            int out = 0;
            ArrayList<Integer> debts = new ArrayList<>();
            String member = "";
            while(!stack.isEmpty()){
                num = 0;
                member = stack.remove(0);
                HashMap<String,Integer> map = graph.getOrDefault(member,new HashMap<String,Integer>());
                for(String person : map.keySet()){
                    int debt = map.get(person);
                    debts.add(debt);
                    num += debt;
                    if(person.equals(key)){
                        for(int i=0;i<debts.size();i++){
                            if(i == 0){out = debts.get(1);}
                            if(debts.get(i) < out){out = debts.get(i);}
                        }
                        return new Cycle(debtors,out);
                    }
                    if(!track.containsKey(person)){
                        track.put(person,num);
                        debtors.add(person);
                        stack.add(person);
                    }
                }
            }
        }
        return null;
    }

}